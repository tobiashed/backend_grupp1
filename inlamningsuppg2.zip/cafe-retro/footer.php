<footer class="footer text-faded text-center py-5">
      <div class="container">
        <p class="m-0 small">Copyright &copy;<?= date("Y");?>
      <br>Kim &bull; Senna &bull; Edit</p>
      </div>
    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  </body>


